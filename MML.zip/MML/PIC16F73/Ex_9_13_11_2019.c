void main() {
    trisC=0b00000001;
    portC=0b00000000;
    trisB=0b00000000;
    portB=0b00000000;
    
    while(1){
     if(portC==0b00000001){
     portB=0b00000001;
     delay_ms(1000);
     }
     if(portC==0b00000000){
     portB=0b00000000;
     delay_ms(1000);
     }
    }

}