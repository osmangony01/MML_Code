void main() {
     trisb=0b00000000;      //output dec.
     portb=0b00000000;      //clear port
     
    while(1)
    {
      portb=0b00000001;      //BO port high
      delay_ms(1000);         // delay
      portb=0b00000000;       //BO port low
      delay_ms(1000);          //delay
    }
}