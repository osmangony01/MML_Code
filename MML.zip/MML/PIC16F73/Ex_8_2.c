void main() {
      trisb=0b00000000;
      portb=0b00000000;

      while(1)
      {
           portb=0b00000001;
          // portb=0b00000000;
          // portb=0b00000000;
           delay_ms(1000);
           
           portb=0b00000010;
           //portb=0b00000000;
           //portb=0b00000000;
           delay_ms(1000);
           
           portb=0b00000100;
           //portb=0b00000000;
           //portb=0b00000000;
           delay_ms(1000);
           

      }
}