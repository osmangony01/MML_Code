void main() {
  trisC=0b00000011;
  portC=0b00000000;
  trisB=0b00000000;
  portB=0b00000000;
  while(1)
  {
   if(portC==0b00000001){
   portB=0b00000101;
   //delay_ms(1000);
   }
   if(portC==0b00000010){
   portB=0b00001010;
   //delay_ms(1000);
   }
   if(portC==0b00000011){
   portB=0b00001001;
   //delay_ms(1000);
   }
   }
   
  
  
}